
import full_gui as gui
from multiprocessing import freeze_support

if __name__ == "__main__":
    freeze_support()
    
    gui.main()

